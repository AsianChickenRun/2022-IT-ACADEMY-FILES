print('*' * 50)
print("\n\tInvoice for Columbus State")
print('\n\t550 East Spring Street')
print('\n\tColumbus, OH 432L5')
tuition = 157.93 * 3
book = 52.99
lab = 25.0
total = tuition + book + lab
print('-' * 50)
print("\n\tProduct Name:\tProduct Price:")
print("\n\tBooks\t\t$", book)
print("\n\tLab Fees\t$", lab)
print("\n\tTuition\t\t$", book)
print('-' * 50)
print("\n\tTotal")
print("\t$", total)
print('-' * 50)
print('Thank you for being a Columbus State Student')
print('*' * 50)
