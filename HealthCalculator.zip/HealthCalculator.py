#stars function
def stars():
    print("*" * 20)

stars()
#user inputs
age = int(input("Age:"))
rate =  int(input("Resting Heart Rate:"))
weight = int(input("Weight [in pounds (lbs.):"))
height = int(input("Height [in inches (in.):"))
#converting pounds to kilograms
def convW(weight):
    kg = weight / 2.046
    return kg

#converting icnhes to meters
def conH(height):
    meters = (height / 39.37) ** 2
    return meters

#operating functions
def bmi(meters, kgs):
    bmi = kgs / meters
    return bmi
def karv(age, rate):
    stars()
    print("Exercise Intensity Heart Rate: ")
    print(" Intensity \t Heart Rate")
    i = 50
    for i in range (50,100,5):
        q = ((((220-age)- rate) *i/100) + rate)
        print(f"{i/100}\t\t{q}")

#activate functions
kg = convW(weight)

meters = conH(height)

bmi = bmi(meters, kg)

#to tell your weight
stars()
print ("Your BMI is...", round(bmi,2))

if bmi < 18.5:
    stars()
    print("You are underweight")
elif bmi >= 18.5 and bmi <= 24.9:
    stars()
    print("You are avg. weight")
elif bmi >= 25 and bmi <= 29.9:
    stars()
    print("You are overweight")
else:
    stars()
    print("You are medically obese")


#I am way too scared to move this operating function
karv(age, rate)

