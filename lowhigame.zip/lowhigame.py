import random
#start loop
while (True):
    # start
    print("Let's Play a Game")
    #inputs
    low = int(input("Lowest Possible Range:"))
    high = int(input("Highest Possible Range:"))
    x = random.randint(low, high)
    guess = int(input("Enter your guess: "))
    while x != "guess":
        print
        if guess < x:
            # guessed to low
            print("guess is low")
            guess = int(input("Enter your guess: "))
        elif guess > x:
            # guessed to high
            print("guess is high")
            guess = int(input("Enter your guess: "))
        else:
            #correct guess
            print("Correct! Great Job!")
            break

    userinput = str.lower(input("Would You like to play again?(Yes/No) "))
    if userinput == "no": print("Thanks for playing!")
    break
        #end loop
