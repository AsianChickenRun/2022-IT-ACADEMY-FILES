symbol = (input("Would you like to Add, Substract, Multiply, or Divide? :"))
print(symbol.lower())

first = int(input("1st number: "))
second = int(input("2nd number: "))

def add(number1, number2):
    return number1 + number2

def subtract(number1, number2):
    return number1 - number2

def multiply(number1, number2):
    return number1 * number2

def divide(number1, number2):
    return number1 / number2

if symbol == "add":
    print(first, "+", second, "=", add(first, second))

elif symbol == "substract":
    print(first, "-", second, "=", subtract(first, second))

elif symbol == "multiply":
    print(first, "*", second, "=", multiply(first, second))

elif symbol == "divide":
    print(first, "/", second, "=",divide(first, second))

else:
    print("Error, Try Again")
